using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pathfinding 
{
   public Pathfinding(int width, int height)
    {

    }
}
